//console.log('Muhammed Essa');

//console.error(  'Muhammed Essa' , err);

// const name = 'muhammed';
//
// console.warn(  `My Name is : ${name}` );
