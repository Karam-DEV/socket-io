var path = require('path');

console.log(path.normalize('/etc/home/muhammed/essa/hameed'));

console.log(path.join('/etc/home/muhammed','/essa/hameed'));

console.log(path.resolve('path.js'));

console.log(path.extname('path.js'));
