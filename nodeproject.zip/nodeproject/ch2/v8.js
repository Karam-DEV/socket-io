const v8 = require('v8');

//console.log(v8.getHeapStatistics());
console.log(v8.getHeapSpaceStatistics());

--max-old-space-size
